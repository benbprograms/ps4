﻿#Region "Imports directives"

Imports System.Net.Mail
Imports System.Net


#End Region

Public Class Form1

    Private Sub word_Click(sender As System.Object, e As System.EventArgs) Handles word.Click


        Process.Start("winword.exe")
    End Sub

    Private Sub ppt_Click(sender As System.Object, e As System.EventArgs) Handles ppt.Click
        Process.Start("powerpnt.exe")
    End Sub

    Private Sub calc_Click(sender As System.Object, e As System.EventArgs) Handles calc.Click
        Process.Start("calc.exe")
    End Sub

    Private Sub crash_Click(sender As System.Object, e As System.EventArgs) Handles crash.Click
        Dim ays As Integer
        ays = MsgBox("are you sure you want to do that?", 36, "are you sure")
        If ays = 6 Then

            Throw New Exception("you asked for it!")
        Else

        End If
    End Sub

    Private Sub Button1_Click(sender As System.Object, e As System.EventArgs) Handles Button1.Click
        Dim url, newURL As String
        url = InputBox("what is the URL of the webpage you want to go to", "enter URL", "www.google.com")
        If Not InStr(url, "www.") Then
            newURL = "www." & url
            Process.Start(newURL)
        Else
            Process.Start(url)
        End If


        'Process.Start(url)
    End Sub

    Private Sub Button2_Click(sender As System.Object, e As System.EventArgs) Handles Button2.Click
        Process.Start("SndVol.exe")
    End Sub

    Private Sub Button4_Click(sender As System.Object, e As System.EventArgs) Handles Button4.Click
        Dim mail As New MailMessage
        Dim toAddr As String
        toAddr = InputBox("enter your email", "to")
        mail.To.Add(toAddr)
        mail.From = New MailAddress("covers.ben.blakemore@gmail.com")
        mail.Subject = "test"

        Dim smtp As New SmtpClient
        smtp.Host = "smtp.gmail.com"
        smtp.Credentials = New NetworkCredential("testvbmail55@gmail.com", "k9H5tSAT5QaZzcYc")
        smtp.EnableSsl = True
        smtp.Port = 465
        smtp.Send(mail)
        smtp.
    End Sub
End Class
